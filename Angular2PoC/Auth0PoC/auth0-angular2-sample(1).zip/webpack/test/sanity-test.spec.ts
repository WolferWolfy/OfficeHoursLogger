import {
  it,
  inject,
  injectAsync,
  beforeEachProviders,
  TestComponentBuilder
} from 'angular2/testing';

describe('sanity checks', () => {
  it('should also be able to test', () => {
    expect(true).toBe(true);
  });
});
